package com.udacity.jwdnd.course1.cloudstorage.config;

public class Constant {

    public static final int KEY_LENGTH = 16;
}
