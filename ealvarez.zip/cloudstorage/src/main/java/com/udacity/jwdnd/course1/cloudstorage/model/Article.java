package com.udacity.jwdnd.course1.cloudstorage.model;

public class Article {

    private Long id;
    private String title;
    private String author;

    public Long getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }
}
