INSERT INTO USERS (username,salt,password,firstname, lastname)
VALUES ('ealvarez','SALT','aqswdefr1', 'Eduardo', 'Alvarez');